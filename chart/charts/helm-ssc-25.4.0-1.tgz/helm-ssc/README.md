This document describes how to configure and use the helm-ssc Helm chart for complete Software Security Center container orchestration in Kubernetes. You can find the Software Security Center Helm chart at <https://hub.docker.com/r/fortifydocker/helm-ssc>.

## Table of contents

- [Kubernetes Versions](#kubernetes-versions)
- [Tool Prerequisites](#tool-prerequisites)
- [Installation](#installation)
- [Upgrade](#upgrade)

## Kubernetes versions

*OpenText recommends running Fortify on the tested platforms described in the product system requirements documentation. However, customers running on other platforms or with untested configurations will be supported until the point OpenText determines that the root cause is the untested platform or configuration. Issues that can be reproduced on the tested platforms will be prioritized and fixed according to standard defect-handling policies.*

These charts have been tested using the following Kubernetes versions:

- Kubernetes 1.32
- Kubernetes 1.33
- Kubernetes 1.34

## Tool prerequisites

- [kubectl v1.32.x](https://kubernetes.io/docs/reference/kubectl/)
- [helm v3.19.x](https://helm.sh/)
- [Java keytool utility ](https://docs.oracle.com/javase/10/tools/keytool.htm)

*OpenText recommends that you use the same tool versions to avoid unpredictable results.*

- For details on installing versions of these tools, see the official [documentation](https://kubernetes.io/releases/version-skew-policy/)

## Installation

The following instructions are for example purposes and are based on a default Kubernetes environment running under Linux, using the default namespace.
Windows systems might require different syntax for some commands and other Kubernetes Cluster providers might require additional/different configurations.
Your Kubernetes administrator might require the use of specific namespaces and/or other configuration adjustments.

### Installation prerequisites

- A working Kubernetes cluster
- A [Kubernetes Storage Class](https://kubernetes.io/docs/concepts/storage/storage-classes/) to use for Software Security Center persistence.
- A [supported database](https://www.microfocus.com/documentation/fortify-software-security-center/) for  Software Security Center system requirements.

### Installation steps

1. [Preparing the Fortify license file](#preparing-the-fortify-license-file)
1. [Prepare the HTTP Certificate Password](#preparing-an-http-certificate-password)
1. [Preparing an httpKeystore file](#preparing-the-http-keystore-file)
1. [Preparing an autoconfig file for Software Security Center](#preparing-the-software-security-center-autoconfig-file)
1. [Preparing a Kubernetes secret for Software Security Center](#preparing-the-software-security-center-kubernetes-secret)
1. [Creating an image pull secret](#creating-an-image-pull-secret)
1. [Installing the Software Security Center release](#installing-the-software-security-center-release)
1. [Setting up port forwarding](#setting-up-port-forwarding-through-kubectl)
1. [Verify Software Security Center is available](#verifying-that-software-security-center-is-available)
1. [Testing the admin login](#testing-the-admin-login)
1. [Special considerations for testing environments](#special-considerations-for-testing-environments)

### Preparing the Fortify license file
- Obtain the Fortify license and store it in the /tmp folder as `fortify-license.txt` so that it can be accessed as /tmp/fortify-license.txt.

### Preparing an HTTP certificate password

- Run the following command to create an HTTP certificate password:

   ```bash
   HTTP_CERT_PWD="$(openssl rand -base64 32)"
   ```

### Preparing the HTTP keystore file

- Run the following command to create the HTTP keystore File
   ```bash
   keytool -genkeypair -keyalg RSA -keysize 2048 -keystore /tmp/httpKeystore.jks -alias ssc-server -storepass $HTTP_CERT_PWD -keypass $HTTP_CERT_PWD -dname "CN=CA, OU=IT, O=OpenText, L=Waterloo, ST=Ontario, C=CN"
   ```
### Preparing the Software Security Center autoconfig file

1. Create a file /tmp/ssc.autoconfig.tpl and copy the following content to it.

   ```bash
   appProperties:
     host.validation: false
     authentication.max.concurrent.logins: -1
     token.management.user.sessionless.tokens.max: 500
     token.management.user.session.tokens.max: 500     

   datasourceProperties:
     db.username: '<DB-USERNAME>'
     db.password: '<DB-PASSWORD>'

     jdbc.url: 'jdbc:sqlserver://<DB-HOST>;database=<DB-NAME>;sendStringParametersAsUnicode=false;trustServerCertificate=true'

   dbMigrationProperties:
     migration.enabled: true
     migration.username: '<DB-USERNAME>'
     migration.password: '<DB-PASSWORD>'
   ```

- This is an example autoconfig file for a MS SQL Server database. You might have to modify this based on your database. Update the values of &lt;DB-USERNAME&gt;,&lt;DB-PASSWORD&gt;, &lt;DB-HOST&gt; and &lt;DB-NAME&gt; for your environment.

### Preparing the Software Security Center Kubernetes secret

1. Use the kubectl create secret command, as shown in the following example code, to create the ssc-secret secret in Kubernetes.
  
   ```bash
   kubectl create secret generic ssc-secret \
    --from-file=/tmp/httpKeystore.jks \
    --from-file=/tmp/fortify-license.txt \
    --from-file=/tmp/ssc.autoconfig.tpl \
    --from-literal=httpCertificateKeyPassword=$HTTP_CERT_PWD \
    --from-literal=httpCertificateKeystorePassword=$HTTP_CERT_PWD
   ```

1. Run the following command to delete the temporary files.

   ```bash
   rm /tmp/httpKeystore.jks /tmp/ssc.autoconfig.tpl /tmp/fortify-license.txt
   ```

1. Run the following command to unset the HTTP certificate password from the terminal.
   ```bash
   unset HTTP_CERT_PWD
   ```
#### Creating an image pull secret

By default, the Software Security Center Helm chart references its images directly from DockerHub. For Kubernetes to properly install your images using the default configuration, you must create an image pull secret and store it in your installation namespace in Kubernetes.
If you are replicating these images to a local repository, you can skip this task and update the relevant image values in the Helm chart to reference your local repository.
To create an image pull secret:
- Use the kubectl create secret command as shown in the following example code:

   ```bash
   kubectl create secret docker-registry docker.io \
    --docker-server=registry-1.docker.io \
    --docker-username='<docker username>' \
    --docker-password='<docker password>' \
    --docker-email='<docker user email>'
   ```

### Installing the Software Security Center release

The following command installs the Software Security Center using the recommended defaults. In some cases, you might need to customize these values using the Helm --set parameter or by creating a values.yaml override file and passing it to the command line with the Helm -f flag. For more information about the values you can override, see the Helm Chart Values table.

Tip:  To find the available Software Security Center Helm chart version, go to https://hub.docker.com/r/fortifydocker/helm-ssc/tags.

- Use the following command to install Software Security Center.

 
   ```bash
   helm install <release-name> oci://registry-1.docker.io/fortifydocker/helm-ssc --version <ssc-helm-chart-version> \
    --set imagePullSecrets[0].name=docker-registry \
    --set secretRef.name=ssc-secret \
    --set secretRef.keys.sscLicenseEntry=fortify-license.txt \
    --set secretRef.keys.sscAutoconfigEntry=ssc.autoconfig.tpl \
    --set secretRef.keys.httpCertificateKeystoreFileEntry=httpKeystore.jks \
    --set secretRef.keys.httpCertificateKeyPasswordEntry=httpCertificateKeyPassword \
    --set secretRef.keys.httpCertificateKeystorePasswordEntry=httpCertificateKeystorePassword \
    --set urlHost=<preferred-ssc-url-hostname>   
   ```

### Setting up port forwarding through kubectl

1. Verify that your Software Security Center pod (ssc-webapp-0) is running successfully. It might take a few minutes before your pod gets to a proper `1/1 Running` configuration. You can run the command above multiple times or use the flag `-w` to watch for any changes.

   ```bash
   kubectl get pods
   ```

1. Open a new terminal shell.

1. Set up port forwarding through kubectl to access your Software Security Center endpoint.

    For example, to forward the `localhost` port `8081`:

   ```bash
   kubectl port-forward  svc/<ssc-service-name> 8081:443
   ```

   `ssc-service-name` can be determined by listing the Kubernetes services using the following command:

   ```bash
   kubectl get services
   ```

### Verifying that Software Security Center is available

1. Follow the steps in [Setting up port forwarding through kubectl](#setting-up-port-forwarding-through-kubectl).

1. You should now be able to access the Software Security Center web endpoint from your browser.

   ```text
   https://localhost:8081
   ```

### Testing the admin login

1. Follow the steps in [Setting up port forwarding through kubectl](#setting-up-port-forwarding-through-kubectl).

1. Access the login endpoint from your browser:

   ```text
   https://localhost:8081
   ```

1. Log in to Software Security Center with the default admin credentials. The default username is admin and the password is admin. You must change the admin password the first time you login.

### Special considerations for testing environments

By default, the Helm chart defines the container resource/requests based on recommended best-practice values intended to prevent performance issues and unexpected Kubernetes evictions of containers and pods. These values are often too large for a small test environment that does not require the same level of resources.
You can override the resource requests by passing additional value `--set resources=null` in the helm install command above.

> WARNING: Using the above option in production is not supported and will lead to unstable behavior.

## Upgrade

This section explains how to upgrade Software Security Center from the previous release to version 25.4.

### Upgrade prerequisites

- A running Software Security Center environment
- Helm access to a Software Security Center environment

### Upgrading from previous version
##### Upgrade steps
1. [Preparing the values file](#preparing-the-values-file)
1. [Upgrading the Software Security Center release](#upgrading-the-software-security-center-release)
1. [Verifying Software Security Center after an upgrade](#verifying-software-security-center-after-the-upgrade)

###  Preparing the values file
Compare the values used in the previous version of the helm chart with the current release [values](#values) and update the values.yaml by merging the values.

### Upgrading the Software Security Center release
Use the 'helm upgrade' command as shown in the below example to upgrade the Software Security Center release.
  
   ```bash
   helm upgrade <Existing Installed SSC Release Name> oci://registry-1.docker.io/fortifydocker/helm-ssc --version <ssc-helm-chart-version>  -f values.yaml --reuse-values
   ```

### Verifying Software Security Center after the upgrade
After the Software Security Center upgrade, verify if [Software Security Center is available](#verifying-that-software-security-center-is-available) and test the [admin login](#testing-the-admin-login).

## Values

The following values are exposed by the Helm Chart. Unless specified as `Required`, only override values as required for your specific environment.

### Required

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| persistentVolumeClaim.size | string | `"4Gi"` | Specifies the size of the persistent volume created for Software Security Center pod. |
| secretRef.keys.httpCertificateKeyPasswordEntry | string | `""` | Specifies the key name for a password of the HTTPS private key. |
| secretRef.keys.httpCertificateKeystoreFileEntry | string | `""` | Specifies the key name for a keystore with certificate and private key for HTTPS. |
| secretRef.keys.httpCertificateKeystorePasswordEntry | string | `""` | Specifies the key name for a password of the HTTPS keystore. |
| secretRef.keys.sscAutoconfigEntry | string | `""` | Specifies the key name for a Software Security Center autoconfig file. |
| secretRef.keys.sscLicenseEntry | string | `""` | Specifies the key name for a Fortify license. |
| secretRef.name | string | `"ssc-secret"` | Specifies the name of an externally managed Kubernetes secret to be used for configuration. |
| urlHost | string | `""` | Specifies the fully qualified DNS name to access the application externally. |

### Other Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | pod.affinity | `{}` | Defines Node Affinity configurations to add to pods. |
| customResources | object | `{"enabled":false,"resources":{}}` | Defines Kubernetes resources to be installed and configured as part of the Helm chart.  If you provide any resources, you must provide them as quoted, using single quotation marks '. |
| customResources.enabled | bool | `false` | Indicates whether to enable custom resource creation. |
| customResources.resources | Kubernetes YAML | `{}` | Specifies the custom resources to generate. |
| environment | list | `[]` | Specifies any additional environment variables to add to the pods. |
| fullnameOverride | string | `{deployment_name}-{service_name}` | Overrides the fully qualified app name of the release. |
| httpClientCertificateVerification | string | `"none"` | Specifies the configuring HTTPS client certificate verification, supported values: "none", "optional", "required". |
| image.pullPolicy | string | `"IfNotPresent"` | Specifies the image pull behavior. |
| image.repository | string | `"fortifydocker/ssc-webapp"` | Specifies the Docker repository from which to pull the Software Security Center Docker image. |
| image.tag | string | `"25.4.0.0137"` |  |
| imagePullSecrets | list | `[]` | Specifies a list of references to secrets in the same namespace to use  for pulling any of the images used by the current release. |
| ingress.annotations | object | `{}` | Specifies annotations to add to the resource. |
| ingress.className | string | `""` | Identifies the Ingress resource class name. |
| ingress.enabled | bool | `false` | Indicates whether to enable Ingress. |
| ingress.hosts[0] | object | `{"host":"ssc.local","paths":[{"path":"/","pathType":"Prefix"}]}` | Specifies the hostname through which to accept requests. |
| ingress.hosts[0].paths[0] | object | `{"path":"/","pathType":"Prefix"}` | Specifies the path through which to accept requests. |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` | Specifies the path type. |
| ingress.tls | list | `[]` | Defines TLS configurations. The setting is expressed in the following format: [{"hosts":["some-host"], "secretName":"some-name"}] |
| ingressScim.annotations | object | `{}` | Specifies annotations to add to the resource. |
| ingressScim.className | string | `""` | Identifies the ingress resource class name. |
| ingressScim.enabled | bool | `false` | Indicates whether to enable IngressScim. |
| ingressScim.hosts[0] | object | `{"host":"ssc-scim.local","paths":[{"path":"/api/scim/v2","pathType":"Exact"}]}` | Specifies the hostname through which to accept requests. |
| ingressScim.hosts[0].paths[0] | object | `{"path":"/api/scim/v2","pathType":"Exact"}` | Specifies the path through which to accept requests. |
| ingressScim.hosts[0].paths[0].pathType | string | `"Exact"` | Specifies the path type. |
| ingressScim.tls | list | `[]` | Defines TLS configurations. The setting is expressed in the following format: [{"hosts":["some-host"], "secretName":"some-name"}] |
| jvmExtraOptions | string | `""` | Specifies a set of additional options passed to the Java process. |
| jvmMaxRAMPercentage | int | `86` | Specifies percentage of memory limit to be used for JVM heap. |
| ldaps.enable | bool | `false` | Indicates whether to enable external LDAP. |
| nameOverride | string | `ssc` | Overrides the name of this chart. |
| nodeSelector | pod.nodeSelector | `{"kubernetes.io/arch":"amd64","kubernetes.io/os":"linux"}` | Defines Node selection constraint configurations to add to the pods. |
| persistentVolumeClaim.annotations | object | `{}` | Persistent Volume Claim annotations. Used when 'existingClaim' is not defined.  |
| persistentVolumeClaim.existingClaim | string | `nil` | Specifies the use of a pre-existing PersistentVolumeClaim.  Supercedes all other PersistentVolumeClaim values. |
| persistentVolumeClaim.selector | object | `{}` | Specifies the Kubernetes PersistentVolumeClaim selector. |
| persistentVolumeClaim.storageClassName | string | `""` | Specifies the storage class name used for the persistent volume. |
| podAnnotations | pod.annotations | `{}` | Defines annotations to add to the pods. |
| priorityClassName | string | `""` | Specifies a priority class for the pod to run as.  Requires an existing PriorityClass to be defined in Kubernetes prior to use.  |
| resources.limits.cpu | int | `8` | Defines the limits of CPU resources granted to the pod. |
| resources.limits.memory | string | `"28Gi"` | Defines the limits of memory resources granted to the pod. |
| resources.requests.cpu | int | `1` | Defines the initial request of cpu resources granted to the pod. |
| resources.requests.memory | string | `"7Gi"` | Defines the initial request of memory resources granted to the pod. |
| saml.enable | bool | `false` | Indicates whether to enable external SAML. |
| secretRef.keys.httpTruststoreFileEntry | string | `""` | Specifies the key name for a truststore used by client certificate verification. |
| secretRef.keys.httpTruststorePasswordEntry | string | `""` | Specifies the key name for a password of the client certificate verification truststore. |
| secretRef.keys.idpCertificateEntry | string | `""` | Specifies the key name for the iDP certificate. Required if SAML enabled. |
| secretRef.keys.jvmTruststoreFileEntry | string | `""` | Specifies the key name for a JVM truststore. |
| secretRef.keys.jvmTruststorePasswordEntry | string | `""` | Specifies the key name for a password of the JVM truststore. |
| secretRef.keys.sscSecretKeyEntry | string | `""` | Specifies the key name for an SSC secret.key file. |
| service.annotations | object | `{}` | Specifies the map of annotations applied to the service. |
| service.clusterIP | string | `""` | Specifies the fixed service cluster IP address, if empty, Kubernetes assigns a value. |
| service.httpPort | int | `80` | Specifies the port to expose for HTTP calls. |
| service.httpsPort | int | `443` | Specifies the port to expose for HTTPS calls. |
| service.loadBalancerIP | string | `""` | Specifies the fixed load balancer IP address. If empty, the Kubernetes cloud provider assigns a value. |
| service.type | string | `"ClusterIP"` | Specifies the type of Service to use. |
| sscPathPrefix | string | `"/"` | Specifies the URL path prefix where the Software Security Center application is accessed. |
| tolerations | pod.tolerations | `[]` | Defines Toleration configurations to add to the pod(s). |
| urlPort | int | `0` | Specifies the HTTPS port for externally accessing the application. If zero, a value of service.httpsPort is used instead. |
| user | pod.securityContext | `{"gid":0,"uid":1111}` | Defines security context configurations to add to the pods. |
